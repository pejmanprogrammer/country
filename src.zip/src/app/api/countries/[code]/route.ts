import { NextResponse } from 'next/server';

interface RouteContext {
  params: Promise<{
    code: string;
  }>;
}

const API_URL =
  'https://api.restcountries.com/countries/v5';

export async function GET(
  _request: Request,
  context: RouteContext,
) {
  const { code } = await context.params;

  const apiKey = process.env.REST_COUNTRIES_API_KEY;

  if (!apiKey) {
    return NextResponse.json(
      {
        message:
          'REST_COUNTRIES_API_KEY is not configured.',
      },
      { status: 500 },
    );
  }

  try {
    const response = await fetch(
      `${API_URL}/codes.alpha_3/${encodeURIComponent(code)}`,
      {
        headers: {
          Authorization: `Bearer ${apiKey}`,
        },
        next: {
          revalidate: 3600,
        },
      },
    );

    if (!response.ok) {
      return NextResponse.json(
        {
          message: 'Country not found.',
        },
        { status: 404 },
      );
    }

    const body = await response.json();

    const countries = body.data ?? body;

    const country = Array.isArray(countries)
      ? countries[0]
      : countries;

    if (!country) {
      return NextResponse.json(
        {
          message: 'Country not found.',
        },
        { status: 404 },
      );
    }

    return NextResponse.json(country);
  } catch {
    return NextResponse.json(
      {
        message: 'Unable to connect to countries API.',
      },
      { status: 500 },
    );
  }
}